import Game from "./images/gta.png"
import { MdClose } from "react-icons/md"
import './CartItem.scss'
export default function CartItem() {

    return <div className='cart-products'>
        <div className='cart-product'>
            <div className='image-container'>
                <img src={Game} alt="game" />
            </div>
            <div className="prod-detail">
                <span className="name"> product name</span>
                <MdClose className="closs-btn" />
                <div className="quantity-buttons">
                    <span>-</span>
                    <span>5</span>
                    <span>+</span>
                </div>
                <div className="text">
                    <span>3</span>
                    <span>x</span>
                    <span className="highlight">&#8377;5855</span>
                </div>

            </div>
        </div>

    </div>
}
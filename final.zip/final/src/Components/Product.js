import Game from "./images/gta.png"
import "./Product.scss"

export default function Product({id,data}){
  const link = "http://localhost:1337"
 
  return  <div className="product-card" >
          <div className="thumbnail">
            
            <img src={link + data.img.data[0].attributes.url} alt="game"></img> </div>
          <div className="prod-details">
              <span className="name">{data.title}</span>
              <span className="price">&#8377;{data.price}</span>
          </div>
  </div>

}
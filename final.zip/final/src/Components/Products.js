import "./Products.scss"
import Product from "./Product"
import React from "react";


export default  function Products({prod,InnerPage}){

    return <div className="products-container">
       { !InnerPage && <div className="sec-heading">Section Heading</div>}
        <div className="products">
            {console.log(prod)}
            {prod.map((item )=> (<Product key={item.id}  id={item.id} data={item.attributes} />))}
            
            
            
        </div>
    </div>
}
import './Category.scss'
import Game from "./images/gta.png"
export default function Category({categories}){
  const  link  =  "http://localhost:1337"
    return (
      <div className="shop-by-category">
        <div className="categories"> 
        {categories.data.map((item) =>   <div key={item.id} className="category">
            <img src={link +item.attributes.img.data.attributes.url} alt=""/>
          </div>  )}
        

        </div>

      </div>

    )
  
  }
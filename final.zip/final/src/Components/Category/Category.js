import Products from "../Products";
import './Category.scss'

function Category(){
    return <div className="category-main-content">
        <div className="layout">
            <div className="category-title">Category Title  </div>
            <Products InnerPage={true}/>
        </div>
    </div>
}

export default Category;

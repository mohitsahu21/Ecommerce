import {MdClose} from "react-icons/md"
import './Search.scss'
import Game from "./images/gta.png"
export default function Search({setShowSearch}){

    return <div className="search-model">
        <div className="form-field">
            <input
            type="text"
            autoFocus
            placeholder="Search for Products"
            />
            <MdClose onClick={()=> setShowSearch(false)}/> 

        </div>
        <div className="search-result-content">
            <div className="search-result">
                <div className="search-result-item">
                    <div className="image-container">
                        <img src={Game} alt="game"></img>
                    </div>
                    <div className="prod-details">
                        <span className="name">Product Name</span>
                        <span className="desc">Product description</span>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
}
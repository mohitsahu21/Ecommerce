
import "./Home.scss"
import Banner from './Banner'
import Category from "./Category";
import Products from "./Products";
import { useEffect ,useContext, useState } from "react";
import { fetchDataFromApi } from "../utils/api";
import { Context } from "../utils/Context";
import React from "react";
import axios from "axios";



export default function Home (){

   const [prod,SetProd] = useState([]);
   
   
   useState(()=>{
      axios.get('http://localhost:1337/api/products?populate=*').then((res) => {
        
         SetProd(res.data.data)
         console.log(res)
      }).catch((err) =>{console.log(err)});
      
   },[])

 


    return <div >
       <Banner/>
       <div className="main-content">
       <div className="layout">
        
         <Products prod={prod}/>
          
          
       </div>
       </div>
    </div>
    
    }
import Game from "./images/gta.png"
import {FaCartPlus} from "react-icons/fa"

import './SingleProduct.scss'
export default function SingleProduct (){
    return <div className='single-product-main-content'>
       <div className='layout'>
        <div className='single-product-page'>
            <div className='left'> <img src={Game} alt="game" /></div>
            <div className='right'>
                <div className="name">Product Name</div>
                <div className="price">500</div>
                <div className="decs">Product Description</div>

                <div className="card-buttons">
                    <div className="quantity-buttons">
                        <span>-</span>
                        <span>5</span>
                        <span>+</span>
                    </div>
                    <button className="add-to-card-button">
                        
                          <FaCartPlus/>
                          Add to Cart
                    </button>
                </div>
            </div>
        </div>
       </div>
    </div>
    
    }